sub init()
   
   m.deviceinfo = getDeviceInfo()
   ?"deviceinfo: ";m.deviceinfo.getDisplaySize()
  
   setScreenBackGrndimage()
   
   searchKeyboard()
 
   resultentList()
  
   setHeader()  
   

   'search result list 
  '  m.ChannelsMarkuGrid = m.top.findnode("ChannelsMarkuGrid")

    'spinner
    m.spinner = m.top.CreateChild("BusySpinner")
    m.spinner.visible = false
    m.spinner.translation = [820, 460]
    m.spinner.uri = "pkg:/images/busyspinner_hd.png"
    
    m.searchStart = m.top.CreateChild("Button")
    ' m.searchStart.focusfootprintBitmapUri ="pkg:/images/Search/mic_focus_icon.png"
    m.searchStart.focusfootprintBitmapUri ="pkg:/images/Search/mic_unfocus_icon.png"
    m.searchStart.translation =[120,130]
    m.searchStart.showFocusFootprint =true
    m.searchStart.minwidth=80
    m.searchStart.maxwidth=80
    m.searchStart.height=50

    m.searchStart.focusedIconUri =""
    m.searchStart.iconUri="" 
    m.searchStart.setFocus(false) 

    m.global.RSG_analytics.trackEvent = {
      google: {
          ec: "Channel_Search_Screen",
          ea: "Launch_complete"
      }
  }
end sub



sub resultentList()
?"resultentList"   
   m.ChannelsMarkuGrid = m.top.createChild("MarkupGrid")   
   m.ChannelsMarkuGrid.id = "ChannelsMarkuGrid"
   m.ChannelsMarkuGrid.translation = "[720,200]" 
   m.ChannelsMarkuGrid.itemComponentName = "ChannellistMarkuGridComponent"
   m.ChannelsMarkuGrid.itemSpacing = "[ 20, 0 ]" 
   m.ChannelsMarkuGrid.rowSpacings = "[ 20, 20 ]" 
   m.ChannelsMarkuGrid. numColumns="3" 
   m.ChannelsMarkuGrid. numRows="3" 
   m.ChannelsMarkuGrid.itemSize="[360,260]" 
                 
   m.ChannelsMarkuGrid.drawFocusFeedback="true"
   m.ChannelsMarkuGrid.visible = false
   m.ChannelsMarkuGrid.observeField("itemSelected","setChannelUrl")
 'show response text 
   m.errorResultLabel = m.top.createChild("Label")
   m.errorResultLabel.text ="Please type some text for search the channels :" 
   m.errorResultLabel.translation = [850, 480]
   m.errorResultLabel.visible = true
end sub

sub setChannelUrl(event as object)
?"setChannelUrl:";event.getRosgnode().content.getchild(event.getRosgnode().itemSelected)   
 m.top.playChannel = event.getRosgnode().content.getchild(event.getRosgnode().itemSelected)
end sub
   
sub setHeader()
?"setHeader"
    Buttonleft = m.top.CreateChild("Button")
    Buttonleft.translation = [1500, 80]
    Buttonleft.iconUri = ""
    butonPoster = Buttonleft.createChild("Poster")
    butonPoster.uri="pkg:/images/home/backNavIcon.png"
    butonPoster.height = 56
    butonPoster.width =  56
    butonLabel = Buttonleft.createChild("Label")
    butonLabel.text ="Go back"
    butonLabel.translation =[80,15]
    
    LabelNav = m.top.CreateChild("Label")
    LabelNav.text ="SEARCH CHANNELS"
    LabelNav.translation = [100, 80]      
end sub
   
sub searchKeyboard()
?"searchKeyboard"  
 m.Searchkeyboard = m.top.createChild("MiniKeyboard")
   m.Searchkeyboard.id = "Searchkeyboard"
   m.Searchkeyboard.translation = "[100,200]"
   m.Searchkeyboard.observeField("text","channelSearchText")
   m.Searchkeyboard.setFocus(true) 
   m.Searchkeyboard .maxheight = 300
   m.Searchkeyboard .width = 300
 
end sub
 
sub setScreenBackGrndimage()
?"setScreenBackGrndimage"
 Poster = m.top.createChild("Poster")
   Poster.id ="Poster"
   Poster.translation ="[0,0]"
   Poster.height=1080
   Poster.width =1920
    
    if m.deviceinfo.getDisplaySize().w = 1920    
          Poster.uri="pkg:/images/homeScreenBckgrnd.png"           
    else if m.deviceinfo.getDisplaySize().w = 1280
          Poster.uri = "pkg:/images/home/homeScreenBckgrndhd.png"      
    else 
          Poster.uri = "pkg:/images/home/homeScreenBckgrndhd.png"
    end if 
    
end sub
sub channelSearchText(event as object)
?"channelSearchText; ";event.getData()
  m.inputText = event.getData()
  if m.ChannelSearchTask<> invalid then m.ChannelSearchTask.control = "Stop"
   
   if Len(m.inputText)>1
     
     m.errorResultLabel.visible = false
   
     m.spinner.visible = true
     m.ChannelSearchTask = CreateObject("roSGNode", "ChannelSearchTask") 'Create XML Parsing task node  
     m.ChannelSearchTask.callType = "POST"
     m.ChannelSearchTask.parameters ={"search":m.inputText} 
     m.ChannelSearchTask.observeField("response","responseAPI")
     m.ChannelSearchTask.control = "RUN"
   else 
     m.ChannelsMarkuGrid.visible = false
     m.errorResultLabel.text ="Please type some text for search the channels :" 
     m.errorResultLabel.visible = true
   end if
   
end sub

sub responseAPI(event as object)
?"SearchScreen::responseAPI: ";event.getData()
  m.errorResultLabel.visible = false
  dataJson = event.getData()
  
  if dataJson.success=true
    ?"dataJson:dataJson:  ";dataJson.data[0]
'    ?"dataJson:dataJson:  ";dataJson.message.data[0]
   if  dataJson.data[0] <> invalid
     m.labelContent = createObject("roSGNode", "ContentNode")
     for each channel in dataJson.data
       ?"Search::chanel details :";channel
       channelDetail=m.labelContent.createChild("ContentNode")
       if channel.callSign<> invalid 
         channelDetail.title = channel.callSign
       else
        channelDetail.title="other"
       end if 
       if channel.url<> invalid then channelDetail.url = channel.url
       if channel.id<> invalid then  channelDetail.id = channel.id
       if channel.logo<> invalid then  channelDetail.HDSMALLICONURL = channel.logo
       if channel.callSign<> invalid then  channelDetail.title = channel.callSign
     end for
     m.ChannelsMarkuGrid.content = m.labelContent
     m.ChannelsMarkuGrid.visible = true
    else
       m.errorResultLabel.text ="No Channels for "+"' "+m.inputText+" '" 
       m.errorResultLabel.visible = true
    end if
  end if     
    
'  m.labelContent.createChild("ContentNode").title=event.getData()
  m.spinner.visible = false
end sub
function recognizer()
  if m.recognizer = invalid
    m.recognizer = CreateObject("roSGNode", "SpeechRecognizer")
    m.recognizer.delegate = m.top
  end if
  return m.recognizer
end function

function speechRecognizerDidReceiveTranscript(transcript as String)
  ?"speechRecognizerDidReceiveTranscript" 
  ?"transcript:"; transcript
   m.spinner.visible = false
   
   m.Searchkeyboard.text = transcript
  ' m.infoLb.text = "Hold the OK button to start dictation, release it once you're done."

  m.searchStart.focusfootprintBitmapUri ="pkg:/images/Search/mic_focus_icon.png"
  m.Searchkeyboard.setFocus(false)   
  m.top.setFocus(true)
end function

function showProgressBar(value as object)

  if value
    m.spinner.visible = true
  else
    m.spinner.visible = false  
  end if
  
end function

Function onKeyEvent(key,press) as object
?"Search screen onKeyEvent";key ;"has focus";m.searchStart.hasFocus() ;"press ";press
result =false
   if press
    if key = "OK" and press
      ?"start voice ..."
      recognizer().callFunc("startListening", {})
      return true
    end if
     ?"SearchScreen: ";key
     ?"m.Searchkeyboard.hasFocus(); ";m.Searchkeyboard.hasFocus()
      if (key="right"  and  m.ChannelsMarkuGrid.visible = true)  then
         m.Searchkeyboard.setFocus(false)
         m.ChannelsMarkuGrid.setFocus(true)
         result = true 
      else if key="left" and m.ChannelsMarkuGrid.hasFocus() then
         m.ChannelsMarkuGrid.setFocus(false)
         m.Searchkeyboard.setFocus(true)   
        result = true 
      else if key="back" then
        m.top.exitView =true
        result = true 
      
      else if m.top.hasFocus() and key="down"
        m.searchStart.focusfootprintBitmapUri ="pkg:/images/Search/mic_unfocus_icon.png"
        m.Searchkeyboard.setFocus(true)   
      else if  key="up"
        m.searchStart.focusfootprintBitmapUri ="pkg:/images/Search/mic_focus_icon.png"
        m.Searchkeyboard.setFocus(false)   
        m.top.setFocus(true)

      end if
     result = true  
   end if
 return result
end function